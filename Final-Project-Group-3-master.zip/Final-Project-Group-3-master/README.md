Group 3's Final Project: Data Shredder

We are creating a website that reads in data sets and organizes them into either a pie chart, a table, a bar graph, or a scatter plot. 

Currently, we only have a few data sets for it to read in, and it can only display them in a table. 

Eventually, we would like the website to be able to display the data in all of the previously mentioned chart types, as well as giving users the option to upload their own data sets to view at their convenience. 
